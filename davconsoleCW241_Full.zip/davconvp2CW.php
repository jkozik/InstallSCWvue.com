<?php
################################################################################
# A Project of TNET Services, Inc. and Saratoga-Weather.org (WD-USA template set)
################################################################################
#
#   Project:    Davis 'Live Console' representation
#   Module:     davconvp2CW.php
#   Purpose:    Davis vp2 console 
#   Authors:    BCJKiwi http://silveracorn.nz/weather
#   Copyright:  (c) 2013 Copyright Silver Acorn Limited
#
################################################################################
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA
################################################################################
# This document uses spaces not tabs
################################################################################
#
# Original code from various sources and specific to Weather Display
# Code supplied to BCJKiwi by Alessandro Bardi of http://www.meteocarmignano.it
# based on work by;
# http://www.axelvold.net
# http://www.nordicweather.net - Weatherstation Pertteli - Henkka
# http://www.stenestad-vader.com - Stenestads Vader
# http://www.teutari.net - Saaasema Teutari
#
# Further info from WD Forum - http://www.weather-watch.com
# Particularly tman1991 (scripts), K3JAE & pinkpanther (Icons)
# Modifications by BCJKiwi May 2013
# http://silveracorn.nz/weather
#
# Single php script, reduction of original separate libraries (some not required)
# Separated css.
# Full customisation for CUMULUS including; 
# replace WD files with Cumulus realtime.txt & new davcon24.txt file supplied by Cumulus to populate the graph data
# Replacement of non-standards compliant marquee with jscroller2, 
#      Copyright (c) 2008 Markus Bordihn (markusbordihn.de)
#
# Addition of button descriptor table below console with active buttons (mixed results with different browsers)
# Rework of code to ensure validation
# Rework of screen layout to better match Vue (original development was for VPro)
# refined/added/resized graphics including rain/cloud/snow combos
# Select forecast icon by decoding Davis forecast strings
# Implemented synchronised page refresh - results may differ with different browsers
# Tested on WinXP/ie8 & Chrome, Win7/ie9, Win8/ie10, Chrome & Firefox
# There are some variations in presentation with different browsers and on some Notebook LCD screens.
# auto selection north/south moon phase icons via latitude
# added max min values to graph (graph scale varies with values)
# Added back WD
# Cumulus testing by PaulMy @ http://www.komokaweather.ca/ - many thanks
# WeatherDisplay testing by gwwilk @ www.gwwilkins.org, and
#                 JGillett @ tiggrweather.net - many thanks.
# Added separate php script for VUE
#
# May 2013     Ver CW1.0   - development version not released
# Sep 2013     Ver CW1.1a  - public release
# Sep 2013     Ver CW1.1c  - fix cumulus moon icon var, reinstate 'GET' retries
# Sep 2013     Ver CW1.1d  - code improvements, fcst & moon icon code moved to functions 
#                          - auto page refresh default changed from 1 hr to 10 mins
#                          - added moonage var to davcon24.txt for Cumulus version
# Oct 2013     Ver CW2.0   - main script now common to both VP2 and VUE with separate include file
#                              for each console type. (Copy/rename vp2 file for Vue - see HowTo instructions) 
#                          - added display of seconds since last update
#                          - general code enhancements
# Oct 2013     Ver CW2.1   - Recoded auto synchronised page refresh
#                          - Upgraded data file settings and checks
# Nov 2013     Ver CW2.1a  - Improved instructions, tidied up some messages
# Nov 2013     Ver CW2.2   - Recoded table buttons below Image, moved settings from -inc, reset table widths
# Nov 2013     Ver CW2.2.1 - Recoded VP2Plus Solar & day night test for improved display, Added Storm Rain
# Dec 2013     Ver CW2.2.2 - Recoded windrose speed / direction to display speed or option to rotate with direction 
# Dec 2013     Ver CW2.2.3 - CU only - removed reference to unused dayfile.txt
# Dec 2013     Ver CW2.2.4 - refined setup for storm rain
# Dec 2013     Ver CW2.2.5 - Added 'Metric' / 'US' date format option settings
# Dec 2013     Ver CW2.3.0 - Revised UoM conversion code in jquery.davconsoleCW.js
#                            Added options for opening links in tabs
# Jan 2014     Ver CW2.4.0 - HTML5. Updated style sheet, added antenna icons
#                            Station Number and data receive indicator
#                            Added further 'Dew' rotation option settings
# Mar 2014     Ver CW2.4.1 - Added options to Graph & Forecast, and to "realtime" Update displays
#                            numerous minor improvements to code 
#
#
################################################################################
# This document uses spaces not tabs
################################################################################
require_once("./Settings.php");
require_once("./common.php");
################################################################################
$useHTML5 = true;  // force this page to use HTML5 instead of XHTML 1.0-Transitional
$useUTF8 = true;   // force this page to convert language files to UTF8 for display
#
$TITLE="Console";
$showGizmo = true;  // set to false to exclude the gizmo
include("./top.php");
################################################################################
// synchronise page refresh to tags upload time - assumes correct time zone set in php scripts to match WXstation location
if (!isset($metrefresh)) { // may be configured in top.php
   if (isset($timeofnextupdate) && $timeofnextupdate != '---' ) {  // standard site variable in Saratoga template for both CU & WD
      $nextupd = (substr($timeofnextupdate,0,2)*60*60) + (substr($timeofnextupdate,3,5)*60); // next update hh:mm as seconds
      $present = (date('H')*60*60) + (date('i')*60) + date('s');                             // now hh:mm:ss as seconds
      if ($nextupd > $present) {$metrefresh = $nextupd - $present + 20;} else {$metrefresh = 620/2;} // handle midnight
   } else { $metrefresh = 620;} // default
}
?>

<meta http-equiv="refresh" content="<?php echo $metrefresh; ?>" />
<link rel="stylesheet" type="text/css" href="./davcon/davconCW.css" />
<!--[if lte IE 8]><script type="text/javascript" src="./davcon/excanvas.min.js"></script><![endif]-->
<script type="text/javascript" src="./davcon/jquery.console.min.js"></script>
<script type="text/javascript" src="./davcon/jquery.flot.min.js"></script>
<script type="text/javascript" src="./davcon/jquery.consolegauge.js"></script>
<script type="text/javascript" src="./davcon/jscroller2-1.61.js"></script>
<script type="text/javascript" src="./davcon/jquery.davconsoleCW.js"></script>
</head>
<body>
<?php
################################################################################
include("./header.php");
################################################################################
include("./menubar.php");
################################################################################
// BEGIN SETTINGS 
################################################################################
// Overrides from Settings.php & Settings-weather.php if available
/* if ( !isset($SITE['DavisVP']) || $SITE['DavisVP'] == false ) { ?> <h1> ERROR - DAVIS CONSOLE REQUIRED </h1> <?php return; }
// not a Davis VP weather station!! */
$latitude   = '1';   // North >= 0, positive, South < 0, negative eg '-1'.  Decimal degrees. Value does not matter, used for moon hemisphere
      if (isset($SITE['latitude']))   {$latitude = $SITE['latitude'];}  // Use Saratoga setting if available
$WXsoftware = 'WD';  // CU for Cumulus | WD for Weather Display | MH for MeteoHub - $SITE settings will over-ride 
      if (isset($SITE['WXsoftware'])) {$WXsoftware = $SITE['WXsoftware'];}  // Use Saratoga setting if available
      if ($WXsoftware == 'CU') {
$dataurl    = './realtime.txt';     // for Cumulus 'realtime' data
      if (isset($SITE['realtimefile']))  {$dataurl = $SITE['realtimefile'];}  // Use Saratoga setting if available
$graphurl   = './davcon24.txt';    // for Cumulus graph data
}

      if ($WXsoftware == 'WD' or $WXsoftware == 'MH') {
$realint  = 5000; // "real time" file clientraw.txt updates interval in millisecs - 5000 = 5 seconds
$dataurl  = './clientraw.txt';       // for Weather Display 'realtime' data
      if (isset($SITE['clientrawfile'])) {$dataurl = $SITE['clientrawfile'];}  // Use Saratoga setting if available
$graphurl = './clientrawextra.txt';  // for Weather Display graph data
 }
      if (!file_exists($dataurl))  {echo '<br /> &nbsp;&nbsp;' . $dataurl  . ' not found! <br />' ; return;}
      if (!file_exists($graphurl)) {echo '<br /> &nbsp;&nbsp;' . $graphurl . ' not found! <br />' ; return;}
      if (file_exists('./sensorlost.php')) {include_once('./sensorlost.php');}
      if (!isset($sensorlost)) {$sensorlost = 0;}
// Settings used in this script and/or in ./davcon/jquery.davconsoleCW.js
$imgdir     = './davcon/'; // path to jquery, css and images with trailing /
      if (!file_exists($imgdir . 'jquery.davconsoleCW.js')) {
         echo '<br /> &nbsp;&nbsp; Check path to images - jquery.davconsoleCW.js not found! <br />' ; return;}
$console    = 'VP2'; // $console = 'VP2'; for VPro2 and VPro2 Plus, $console = 'VUE'; for Vue
$vp2Plus    = 'N';   // $vp2Plus = 'Y' for VPro2 Plus - i.e ET/UV/Solar, $vp2Plus = 'N' if Not Plus
$uomsys     = 'M';   // WD Users Only - $uomsys = 'M'; for Metric units, $uomsys = 'I'; for Imperial (English) units
// Station number(s) - replace unused station numbers (' &nbsp;') with station number (e.g. '2&nbsp;')
                     // at relevant location (or wherever you like!) NOTE:- VUE only has space for 6
//$stnnumbrs= '1&nbsp;' . '2&nbsp;' . '3&nbsp;' . '4&nbsp;' . '5&nbsp;' . '6&nbsp;' . '7&nbsp;' . '8&nbsp;';
$stnnumbrs  = '1&nbsp;' . ' &nbsp;' . ' &nbsp;' . ' &nbsp;' . ' &nbsp;' . ' &nbsp;' . ' &nbsp;' . ' &nbsp;';
$showstnnum = true;  // $showstnnum = true; OR $showstnnum = false;
$showantenna= true;  // $showantenna = true; OR $showantenna = false;
// Settings for timing of 'live' image data rotate and compass pointer refresh behaviour
$itimeout   = 3;     // time between image updates in seconds
                     // default 3 = frequency of rotating data updates in secs ( compass, dew, rain, ET/UV/Solar )
                     // recommend this be set to some even divisor of the 'realtime' update time.
$windrotate = 2;     // 1 = Wind speed only in wind rose
                     // 2 = wind speed -> wind direction -> wind speed
$dewrotate  = 4;     // 1 = Apparent   -> Dew
                     // 2 = Humidex    -> Dew
                     // 3 = Heat Index -> Dew
                     // 4 = Apparent   -> Chill -> Dew
                     // 5 = Humidex    -> Chill -> Dew
                     // 6 = Heat Index -> Chill -> Dew
                     // 7 = Apparent   -> Chill -> Heat Index -> Dew
                     // 8 = Humidex    -> Chill -> Heat Index -> Dew
$dayrnrotate= 2;     // 1 = Daily rain only or if vp2Plus = 'Y' Daily rain -> E-Trans -> Daily rain
                     // 2 = Daily rain -> Storm rain -> Daily rain
                     //       or if vp2Plus = 'Y' Daily rain -> E-Trans -> Storm rain -> Daily rain
$timeformat = 1;     // 1 = Time display in 'metric' format   hh:mm
                     // 2 = Time display in 'Imperial' format hh:mm am/pm
$dateformat = 1;     // 1 = Date display in 'metric' format   dd/mm
                     // 2 = Date display in 'Imperial' format mm/dd
$showupdate = 1;     // 0 - Don't display message,
                     // 1 - Display Next Graph and Forecast update @ ~ HH:mm,
                        // Requires var $timeofnextupdate to be updating correctly - can be an issue with some WD systems
                        // WD Users - if $timeofnextupdate in testtags.php is not present in, or not showing the right time, then
                        // please carefully review Ken True's setup guide at http://saratoga-weather.org/wxtemplates/setup-WD.php 
                     // 2 - Display Graph and Forecast last updated @ HH:mm
// Show age of "real time" data file in table below console image - "Realtime" data updated ss secs ago"
$showage    = 1;     // requires './davcon/showage.js' file to determine age and run counter 
                     // 0 = Don't display message
                     // 1 = Display Next "Realtime" data in ~ ss secs (counts down to 0!)
                        // Option 1 also requires mods to ajaxCUwx.js (Cumulus) / ajaxWDwx.js (Weather Display) - refer HowTo for details
                        // requires ajaxCUwx.js (Cumulus) / ajaxWDwx.js (Weather Display)
                        // requires maxupdates = 0; in ajaxCUwx.js/ajaxWDwx.js or in whatever equivalent your site uses
                        // else secs will continue to increase after the number of updates set is reached.
                     // 2 Display "Realtime" data updated ss secs ago

// Define external scripts for buttons on console image and in table below image
// Define the text displayed beside the button. Change the text between " " as in $....btntxt = "some text";
// To disable button function but retain button and legend, define $....btntxt as = ""; NO SPACE! - will also disable console button
$fcastbtn     = './wxcutrends.php';       // forecast button
      $WxCenbtn   = $fcastbtn;            // WXcen button - for Vue
$fcastbtntxt  = "Trends, Records and Statistics";  // forecast/WxCen button text NOTE:- Enclose in " " not ' '!
      $WxCenbtntxt= $fcastbtntxt;         // WXcen button - for Vue

$graphbtn     = './wxcugraphs.php';       // graph button
$graphbtntxt  = "Cumulus Graphs for Last 48 hrs";  // graph button text NOTE:- Enclose in " " not ' '!

$hilowbtn     = './wxcumnthall.php';      // hilow button
$hilowbtntxt  = "Cumulus Month / Alltime Data"; // hilow button text NOTE:- Enclose in " " not ' '!

$alarmbtn     = './wxdatasummary.php';    // alarm button
      $timebtn    = $alarmbtn;            // time button - for Vue
$alarmbtntxt  = "Annual Data";            // alarm/time button text NOTE:- Enclose in " " not ' '!
      $timebtntxt = $alarmbtntxt;         // time button - for Vue

$donebtn      = './wxstatus.php';         // done button
$donebtntxt   = "Station Status";         // done button text NOTE:- Enclose in " " not ' '!

$taboption    = 1;                        // 1 - Open Console Buttons in Console Tab & Table Buttons in New Tab
                                          // 2 - Open Console buttons in New Tab & Table Buttons in Console Tab
                                          // 3 - Open All Button Links in New Tabs
                                          // 4 - Open All Button Links in Console Tab
$showtooltip  = true;                     // true  - display 'NewTab' tooltip when using $taboption 1, 2 or 3
                                          // false - DON'T display 'NewTab' tooltip when using $taboption 1, 2 or 3
################################################################################
// END Settings
################################################################################
// Load include file for console type - all console type specific code
if ($console != 'VUE') {require_once("./davconvp2CW-inc.php");} else {require_once("./davconvueCW-inc.php");}

// Forecast Icon
$fcsticon = get_fcsticon($vpforecasttext);

// Moon Icon
$moonic = get_moon($moonage,$latitude);

// make php variables available for use in both this script and / or jquery.davconsoleCW.js
?>
<script type="text/javascript">
var wxsoftware  = '<?php echo $WXsoftware; ?>'
var dataurl     = '<?php echo $dataurl; ?>'
var realint     = '<?php echo $realint; ?>'
var imgdir      = '<?php echo $imgdir; ?>'
var console     = '<?php echo $console; ?>'
var showsolar   = '<?php echo $showsolar; ?>'
var VPet        = '<?php echo $VPet; ?>'
var uomsys      = '<?php echo $uomsys; ?>'
var itimeout    = '<?php echo $itimeout; ?>'
var windrotate  = '<?php echo $windrotate; ?>'
var dewrotate   = '<?php echo $dewrotate; ?>'
var vpstormrain = '<?php echo $vpstormrain; ?>'
var dayrnrotate = '<?php echo $dayrnrotate; ?>'
var timeformat  = '<?php echo $timeformat; ?>'
var dateformat  = '<?php echo $dateformat; ?>'
var fcastbtn    = '<?php echo $fcastbtn; ?>'
var WxCenbtn    = '<?php echo $WxCenbtn; ?>'
var graphbtn    = '<?php echo $graphbtn; ?>'
var hilowbtn    = '<?php echo $hilowbtn; ?>'
var alarmbtn    = '<?php echo $alarmbtn; ?>'
var timebtn     = '<?php echo $timebtn; ?>'
var donebtn     = '<?php echo $donebtn; ?>'
var fcsticon    = '<?php echo $fcsticon; ?>'
var moonic      = '<?php echo $moonic; ?>'
var sensorlost  = '<?php echo $sensorlost; ?>'
</script>
<?php if ($showage) { ?> <script type="text/javascript" src="./davcon/showage.js"></script> <?php } ?>
<br/>
<div style="width:700px; margin: 0 auto; text-align:left; font-size:10px;">
Based on script by <a rel="external" href="http://www.axelvold.net">Axelvold's weather &amp; Photo</a> and
   <a rel="external" href="http://www.stenestad-vader.com/">Stenestads Vader</a><br />
Modification by
   <a rel="external" href="http://www.nordicweather.net/">Weatherstation Pertteli</a> and
   <a rel="external" href="http://www.lokaltvader.se/">Saro/Budskars Vader</a><br />
Graphics, icons and code revised by
   <a rel="external" href="http://silveracorn.nz/weather/">Silver Acorn Weather</a><span style="font-size:7px; color:gray">&nbsp;v2.4.1</span>
</div>

<script type="text/javascript">
// GRAPHS
<!--
   var d1 = <?php echo $temp ?>;
   var d2 = <?php echo $hum  ?>;
   var d3 = <?php echo $wind ?>;
   var d4 = <?php echo $rain ?>;
   var d5 = <?php echo $baro ?>;
   var d6 = <?php echo $solr ?>;

   var options = {
      xaxis: {mode:null},
      yaxis: {mode:null},
      grid:  {show:false},
      legend:{ show:false}
   };

   var data = {
      data: d1, 
      points: { show: true, fill: true,fillColor: "#053D6C",radius: 1 },
      color: "#053D6C",
      shadowSize: 1
   };

   var data2 = {
      data: d2, 
      points: { show: true, fill: true,fillColor: "#053D6C",radius: 1 },
      color: "#053D6C",
      shadowSize: 1
   };

   var data3 = {
      data: d3, 
      points: { show: true, fill: true,fillColor: "#053D6C",radius: 1 },
      color: "#053D6C",
      shadowSize: 1
   };

   var data4 = {
      data: d4, 
      points: { show: true, fill: true,fillColor: "#053D6C",radius: 1 },
      color: "#053D6C",
      shadowSize: 1
   };

   var data5 = {
      data: d5, 
      points: { show: true, fill: true,fillColor: "#053D6C",radius: 1 },
      color: "#053D6C",
      shadowSize: 1
   };

   var data6 = {
      data: d6, 
      points: { show: true, fill: true,fillColor: "#053D6C",radius: 1 },
      color: "#053D6C",
      shadowSize: 1
   };
<!-- console -->
   var plot = $.plot($("#placeholder"), [data], options);
   $("#tempbtn").click(function()  { var plot = $.plot($("#placeholder"), [data],  options);
      $("#grlab").unbind('click').html('<?php echo "TEMP"; ?>');
      $("#grmax").unbind('click').html('<?php echo $tmax;  ?>');
      $("#grmin").unbind('click').html('<?php echo $tmin;  ?>');
   });

   $("#humbtn" ).click(function()  { var plot = $.plot($("#placeholder"), [data2], options);
      $("#grlab").unbind('click').html('<?php echo "HUM";  ?>');
      $("#grmax").unbind('click').html('<?php echo $hmax;  ?>');
      $("#grmin").unbind('click').html('<?php echo $hmin;  ?>');
   });

   $("#windbtn").click(function()  { var plot = $.plot($("#placeholder"), [data3], options);
      $("#grlab").unbind('click').html('<?php echo "WIND"; ?>');
      $("#grmax").unbind('click').html('<?php echo $wmax;  ?>');
      $("#grmin").unbind('click').html('<?php echo $wmin;  ?>');
   });

   $("#rainbtn").click(function()  { var plot = $.plot($("#placeholder"), [data4], options);
      $("#grlab").unbind('click').html('<?php echo "RAIN"; ?>');
      $("#grmax").unbind('click').html('<?php echo $rmax;  ?>');
      $("#grmin").unbind('click').html('<?php echo $rmin;  ?>');
    });

   $("#barbtn" ).click(function()  { var plot = $.plot($("#placeholder"), [data5], options);
      $("#grlab").unbind('click').html('<?php echo "BAR";  ?>');
      $("#grmax").unbind('click').html('<?php echo $bmax;  ?>');
      $("#grmin").unbind('click').html('<?php echo $bmin;  ?>');
   });

   $("#solarbtn").click(function()  { var plot = $.plot($("#placeholder"), [data6], options);
      $("#grlab").unbind('click').html('<?php echo "SOL"; ?>');
      $("#grmax").unbind('click').html('<?php echo $smax;  ?>');
      $("#grmin").unbind('click').html('<?php echo $smin;  ?>');
    });
<!-- table -->
   $("#tempbtnt").click(function() { var plot = $.plot($("#placeholder"), [data],  options);
      $("#grlab").unbind('click').html('<?php echo "TEMP"; ?>');
      $("#grmax").unbind('click').html('<?php echo $tmax;  ?>');
      $("#grmin").unbind('click').html('<?php echo $tmin;  ?>');
   });

   $("#humbtnt" ).click(function() { var plot = $.plot($("#placeholder"), [data2], options);
      $("#grlab").unbind('click').html('<?php echo "HUM";  ?>');
      $("#grmax").unbind('click').html('<?php echo $hmax;  ?>');
      $("#grmin").unbind('click').html('<?php echo $hmin;  ?>');
   });

   $("#windbtnt").click(function() { var plot = $.plot($("#placeholder"), [data3], options);
      $("#grlab").unbind('click').html('<?php echo "WIND"; ?>');
      $("#grmax").unbind('click').html('<?php echo $wmax;  ?>');
      $("#grmin").unbind('click').html('<?php echo $wmin;  ?>');
   });

   $("#rainbtnt").click(function() { var plot = $.plot($("#placeholder"), [data4], options);
      $("#grlab").unbind('click').html('<?php echo "RAIN"; ?>');
      $("#grmax").unbind('click').html('<?php echo $rmax;  ?>');
      $("#grmin").unbind('click').html('<?php echo $rmin;  ?>');
   });

   $("#barbtnt" ).click(function() { var plot = $.plot($("#placeholder"), [data5], options);
      $("#grlab").unbind('click').html('<?php echo "BAR";  ?>');
      $("#grmax").unbind('click').html('<?php echo $bmax;  ?>');
      $("#grmin").unbind('click').html('<?php echo $bmin;  ?>');
   });

   $('a[rel*="external"]').click( function() {
      window.open(this.href);
      return false;
   });
//-->
</script>
</div>

<?php
// Forecast Icon
function get_fcsticon($vpforecasttext) {
// Determine forecast icon from Davis forecast string $vpforecasttext
$DC_fcsttmp = "DC_{$vpforecasttext}";  // Station forecast string
// echo '<br />';
// echo $DC_fcsttmp;
// echo '<br />';
// echo $vpforecasttext;
// !!! DO NOT CHANGE ANY OF THESE STRING TESTS !!!
// !!! TESTS and ORDER CRITICAL !!!
if (
   preg_match('/Mostly clear/i',                        $DC_fcsttmp) )    // mclr.png
      {$fcsticon = "mclr.png";} else if (
   preg_match('/increasing clouds and warmer/i',        $DC_fcsttmp) ||   // pcld.png
   preg_match('/warmer. Precipitation possible within 24/i', $DC_fcsttmp) ||   // pcld.png
   preg_match('/Increasing clouds with/i',              $DC_fcsttmp) ||   // pcld.png
   preg_match('/Partly cloudy/i',                       $DC_fcsttmp) )    // pcld.png
      {$fcsticon = "pcld.png";} else if (
   preg_match('/cooler. precipitation possible within 12/i', $DC_fcsttmp) ||   // rain.png
   preg_match('/cooler. Precipitation likely. Windy/i', $DC_fcsttmp) )    // rain.png
      {$fcsticon = "rain.png";} else if (
   preg_match('/Precipitation ending within 6/i',       $DC_fcsttmp) ||   // mcld.png
   preg_match('/clearing, cooler and windy/i',          $DC_fcsttmp) ||   // mcld.png
   preg_match('/mostly cloudy and cooler/i',            $DC_fcsttmp) ||   // mcld.png
   preg_match('/Mostly cloudy with/i',                  $DC_fcsttmp) ||   // mcld.png
   preg_match('/change. possible wind shift/i',         $DC_fcsttmp) ||   // mcld.png
   preg_match('/likely/i',                              $DC_fcsttmp) ||   // mcld.png
   preg_match('/change. precipitation possible within 24/i', $DC_fcsttmp) ||   // mcld.png
   preg_match('/Precipitation likely possibly/i',       $DC_fcsttmp) ||   // mcld.png
   preg_match('/Precipitation possible within 24/i',    $DC_fcsttmp) ||   // mcld.png
   preg_match('/Precipitation possible within 48/i',    $DC_fcsttmp) ||   // mcld.png
   preg_match('/Unsettled/i',                           $DC_fcsttmp) )    // mcld.png
      {$fcsticon = "mcld.png";} else if (
   preg_match('/precipitation continuing/i',            $DC_fcsttmp) ||   // rain.png
   preg_match('/windy within 6/i',                      $DC_fcsttmp) ||   // rain.png
   preg_match('/possible within 12/i',                  $DC_fcsttmp) ||   // rain.png
   preg_match('/possible within 6/i',                   $DC_fcsttmp) ||   // rain.png
   preg_match('/ending in/i',                           $DC_fcsttmp) ||   // rain.png
   preg_match('/ending within 12/i',                    $DC_fcsttmp) )    // rain.png
      {$fcsticon = "rain.png";} else if (
   preg_match('/Partialy cloudy, Rain possible/i',      $DC_fcsttmp) )    // pcldrain.png
      {$fcsticon = "pcldrain.png";} else if (
   preg_match('/Mostly cloudy, Rain possible/i',        $DC_fcsttmp) )    // mcldrain.png
      {$fcsticon = "mcldrain.png";} else if (
   preg_match('/Partialy cloudy, Snow/i',               $DC_fcsttmp) )    // pcldsnow.png
      {$fcsticon = "pcldsnow.png";} else if (
   preg_match('/Mostly cloudy, Snow/i',                 $DC_fcsttmp) )    // pcldsnow.png
      {$fcsticon = "mcldsnow.png";} else if (
   preg_match('/Rain and/i',                            $DC_fcsttmp) )    // rainsnow.png
      {$fcsticon = "rainsnow.png";} else if (
   preg_match('/Clear/i',                               $DC_fcsttmp) ||   // mclr.png  - LaCrosse & Oregon Scientific
   preg_match('/Sunny/i',                               $DC_fcsttmp) )    // mclr.png  - LaCrosse & Oregon Scientific
      {$fcsticon = "mclr.png";} else if (
   preg_match('/Cloudy/i',                              $DC_fcsttmp) )    // mcld.png  - LaCrosse & Oregon Scientific
      {$fcsticon = "mcld.png";} else if (
   preg_match('/Rain/i',                                $DC_fcsttmp) )    // rain.png  - LaCrosse & Oregon Scientific
      {$fcsticon = "rain.png";} else if (
   preg_match('/Snow/i',                                $DC_fcsttmp) )    // snow.png  - LaCrosse & Oregon Scientific
      {$fcsticon = "snow.png";} else if (
   preg_match('/FORECAST/i',                            $DC_fcsttmp) )    // FORECAST REQUIRES 3 HOURS OF RECENT DATA
      {$fcsticon = "grid.png";} else {            // forecast not found !!
   $DC_fcsttmp = "$DC_fcsttmp|grid.png|\n";
file_put_contents( "./davconfcst.txt" , $DC_fcsttmp , FILE_APPEND); // write un-matched forecast to davconfcst.txt
$fcsticon = "grid.png";
}
return $fcsticon;
}

// Moon icon selection
function get_moon($moonage,$latitude) {
$moonagedays = preg_replace('|^Moon age:\s+(\d+)\s.*$|is',"\$1",$moonage);
$topmoon = round($moonagedays,1);
$ns = ($latitude < 0 ) ? 's' : 'n';
   if($topmoon <= 1   || $topmoon >= 27.7) { $moonic = $ns . "moonnew.png";  } else
   if($topmoon > 1    && $topmoon <= 6.5)  { $moonic = $ns . "moonwaxc.png"; } else
   if($topmoon > 6.5  && $topmoon <= 7.5)  { $moonic = $ns . "moonfqtr.png"; } else
   if($topmoon > 7.5  && $topmoon <= 13.5) { $moonic = $ns . "moonwaxg.png"; } else
   if($topmoon > 13.5 && $topmoon <= 14.5) { $moonic = $ns . "moonfull.png"; } else
   if($topmoon > 14.5 && $topmoon <= 20.5) { $moonic = $ns . "moonwang.png"; } else
   if($topmoon > 20.5 && $topmoon <= 21.5) { $moonic = $ns . "moonlqtr.png"; } else
   if($topmoon > 21.5 && $topmoon <  27.7) { $moonic = $ns . "moonwanc.png"; }
return $moonic;
}

############################################################################
include("./footer.php");
############################################################################
# End of Page
############################################################################
?>
