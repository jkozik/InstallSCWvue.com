/*
Settings file for JQuery plugin for rendering gauges
* Initial create by Henkka (as jquery.console.js v. 1.0), Jan 2010
* Cumulus customisation by BCJKiwi, May 2013  http://silveracorn.co.nz/weather/
* reworked completely for Cumulus, added back WD.
* auto-rotate rain, dew/apparent temp, and Temp in/ET UV Solar values.
* Added timeout and retry to make Datafile Get routine more reliable.
* added routine to display israining umbrella icon.
* turn off ET/UV/Solar rotation at night.
*** setting options in calling php script ***
* 1.1d added imperial unit variants for rain decimal places, and for barotrend arrow
* 1.1e revised barotrend arrow position code
* 2.0 revised for php Ver CW2.0
* 2.2.1 revised for php Ver CW2.2.1 - recoded solar tests, added storm rain.
* 2.2.2 revised for php Ver CW2.2.2 - recoded windrose wind speed / degrees presentation.
* 2.2.4 revised for php Ver CW2.2.4
* 2.2.5 revised for php Ver CW2.2.5 - Added 'Metric' / 'US' date format option settings
* 2.3.0 revised for php Ver CW2.3.0 - recoded variable units conversion sections
* 2.4.0 revised for php Ver CW2.4.0 - added antenna icons for Vue, station number for VP2
*                                   - added 'X' signal lost for VP2
* 2.4.1 revised for php Ver CW2.4.1 - changed term to Storm Rain

*/

$(function() {
   var avgwinddotsoffset = 14;
   var options = {};
   var data = '';
   var alreadyFetched = {};
   var cr = '';
   var windbutton = 0;
   var dayrainbutton = 0;
   var rainbutton = 0;
   var appbutton  = 0;
   var tempinbutton = 0;
   var antennaicon = 0;
   var crcache = {};

   update();
   function update() {
      //Reset data
      alreadyFetched = {};
      function onDataReceived(series) {

// ### CUMULUS REALTIME.TXT  ##################################
         if (wxsoftware == 'CU') {
// We need some some values from realtime.txt
// split realtime.txt
            var cr = series.split(' ');
// TIME AND DATE
            var dateonly  = cr[0];                 // Cumulus realtime Date ALWAYS dd/mm/yy
            var timeonly  = cr[1];                 // Cumulus realtime Time always hh:mm:ss
   // Time
            if (timeformat != 2) {                 // Metric default
               var hourmin = timeonly.slice(0, 5); // for time as hh:mm - takes first 5 chars from hh:mm:ss
               var ampm = ' ';                     // no am pm indicator
            } else {                               // Imperial alternate
               var hh = timeonly.slice(0, 2);
               var mm = timeonly.slice(3, 5);
               var ampm = (hh > 11) ? 'pm' : 'am';
               if (hh > 12) {hh = hh - 12;}
               var hourmin = hh + ':' + mm;
            }
   // date
            if (dateformat != 2) {                 // Metric default
               var daymon = dateonly.slice(0, 5);  // delivers date as dd/mm
            } else {                               // Imperial option
               var daymon = dateonly.slice(3,5)+'/'+ dateonly.slice(0,2);  // delivers date as mm/dd
            }
            $("#cajaxddmo").html(daymon);
            $("#cajaxhhmm").html(hourmin);
            $("#cajaxampm").html(ampm);
// TEMP
            var crtemp = (cr[2] * 1).toFixed(1);   // Outside temp
            crtemp = crtemp.replace("-100.0", "-- ");
            $("#cajaxtemp").html(crtemp);
            var critemp = (cr[22] * 1).toFixed(1); // Inside temp
            critemp = critemp.replace("-100.0", "-- ");
            $("#cajaxitemp").html(critemp);
            var crdew  = (cr[4] * 1).toFixed(1);   // Dew point
            var crtempu = '&deg;'+ cr[14];
// APPARENT TEMP
            var crapp  =  cr[54];                  // Apparent Temperature
            crapp = crapp.replace("-100.0", "-- ");
            $("#cajaxapp").html(crapp);
            var crchill = (cr[24] * 1).toFixed(1); // Wind Chill
            var crheat  = (cr[41] * 1).toFixed(1); // Heat Index
            var crhdex  = (cr[42] * 1).toFixed(1); // Humidex
// HUMIDITY
            var crhum = cr[3];                     // Outside Humidity
            $("#cajaxhumidity").html(crhum);
            var crihum = cr[23];                   // Inside Humidity
            $("#cajaxihumidity").html(crihum);
// WIND
//            var cravg  =  cr[5];                   // Wind speed (average)
            var crwspd = (cr[6] * 1).toFixed(1);   // Wind speed (latest)
            $("#cajaxwind").html(crwspd);
            var crwindu = cr[13].toUpperCase();    // UOM Wind Speed
            var cradir = cr[7];                    // Wind Bearing (degrees)
// BAROMETER
            var crbaro  = (cr[10] * 1).toFixed(2); // Barometer
            $("#cajaxbaro").html(crbaro);
            var crtre = ((cr[15] == 'hPa') || (cr[15] == 'mb')) ? get_barotrendmet(cr[18]) : get_barotrendimp(cr[18]);
// UMBRELLA ICON
       // Davis manual states "Rain Rate will show zero and the umbrella icon does not appear
       // until two tips of the rain bucket within a 15 minute period." Min rain rate for Umbrella icon - => 1.6mm/hr or 0.08"/hr
            if (cr[8] > 0) { $("#cajaxumbr").html('<img src="' + imgdir + "umbr.png" + '" alt=""/>');
            } else { $("#cajaxumbr").html(''); }
// RAIN
            var crrainu = cr[16];                     // Rain UoM
            $("#cajaxrainu").html(crrainu);
            var crrainuh = (cr[16]+'/h');             // Rain Rate UoM
            $("#cajaxrainuh").html(crrainuh);
            var dec = (crrainu != 'in') ? 1 : 2;      // Metric 'mm' 1 dec place Imp 'in' = 2 dec places
            var crrainr = (cr[8]  * 1).toFixed(dec);  // Rain rate
            var crrainh = (cr[47] * 1).toFixed(dec);  // Rain last hour
            var crraind = (cr[9]  * 1).toFixed(dec);  // Rain so far today
            $("#cajaxrain").html(crraind);
            var crrainm = (cr[19] * 1).toFixed(dec);  // Rain this month
            var crrainy = (cr[20] * 1).toFixed(dec);  // Rain this year
            var stormrn = (vpstormrain * 1).toFixed(dec);   // Storm rain
            var stormrntxt = 'STORM&nbsp;&nbsp;RAIN';
// SOLAR ET UV
            if (showsolar == 'Y') {
               var cret = (cr[44] * 1).toFixed(dec);  // Evapotrans metric 1 dec place imp 2 dec
               var cruv    = (cr[43] * 1).toFixed(1); // UV Index
               var crsolar = (cr[45] * 1).toFixed(0); // Solar Radiation W/m2
            }

// ### WEATHER DISPLAY CLIENTRAW.TXT  ##################################
// default configuration is for Metric units.
// Options shown remmed out
// To change to your units to match your station if different, replace unwanted units with wanted units.
         } else if (wxsoftware == 'WD') { // split clientraw
// We need some some values from clientraw
// split clientraw.txt
         var cr = series.split(' ');
// TIME AND DATE
            var dy = cr[35]; if ( dy < 10 ) {dy = '0' + dy;}
            var mo = cr[36];
            var hh = cr[29];
            var mm = cr[30];
   // Time
            if (timeformat != 2) {           // Metric default
               var hourmin = hh + ':' + mm;  // 24 hr 
               var ampm = ' ';               // no am pm indicator
            } else {                         // Imperial
               var ampm = (hh > 11) ? 'pm' : 'am';
               if (hh > 12) {hh = hh - 12;}  // 12 hour
               var hourmin = hh + ':' + mm;  // 12 hour
            }
   // Date
            if (dateformat != 2) {           // Metric default
               var daymon = dy + '/' + mo;   // Day/Month
            } else {
               var daymon = mo + '/' + dy;   // Month/Day
            }
            $("#cajaxddmo").html(daymon);
            $("#cajaxhhmm").html(hourmin);
            $("#cajaxampm").html(ampm);
// TEMP
            var crtemp = (uomsys != 'I') ? (cr[4] * 1).toFixed(1) : (cr[4] * 1.8 + 32).toFixed(1);       // deg C : F
            crtemp = crtemp.replace("-100.0", "-- ");
            $("#cajaxtemp").html(crtemp);
            var critemp = (uomsys != 'I') ? (cr[12] * 1).toFixed(1) : (cr[12] * 1.8 + 32).toFixed(1);    // deg C : F
            critemp = critemp.replace("-100.0", "-- ");
            $("#cajaxitemp").html(critemp);
            var crdew = (uomsys != 'I') ? (cr[72] * 1).toFixed(1) : (cr[72] * 1.8 + 32).toFixed(1);      // deg C : F
            var crtempu =  (uomsys != 'I') ? '&deg;' + 'C' : '&deg;' + 'F';                              // deg C : F
// APPARENT TEMP
            var crapp = (uomsys != 'I') ? (cr[130] * 1).toFixed(1) : (cr[130] * 1.8 + 32).toFixed(1);    // deg C : F - Apparent temp
            crapp = crapp.replace("-100.0", "-- ");
            $("#cajaxapp").html(crapp);
            var crchill = (uomsys != 'I') ? (cr[44] * 1).toFixed(1) : (cr[44] * 1.8 + 32).toFixed(1);    // deg C : F - Wind Chill
            var crheat  = (uomsys != 'I') ? (cr[112] * 1).toFixed(1): (cr[112] * 1.8 + 32).toFixed(1);   // deg C : F - Heat Index
            var crhdex  = (uomsys != 'I') ? (cr[45] * 1).toFixed(1) : (cr[45] * 1.8 + 32).toFixed(1);    // deg C : F - Humidex
// HUMIDITY
            var crhum = cr[5];   // OUTside Humidity
            $("#cajaxhumidity").html(crhum);
            var crihum = cr[13];   // INside Humidity
            $("#cajaxihumidity").html(crihum);
// WIND
            //             var crwspd = (cr[1] * 1).toFixed(1);             // knots (average)
            //             var crwspd = (cr[1] * 0.5144444).toFixed(2);     // knots -> m/s
            var crwspd  = (uomsys != 'I') ? (cr[1] * 1.852).toFixed(1) : (cr[1] * 1.1507794).toFixed(1); // knots -> km/hr : mph
            var crwindu = (uomsys != 'I') ? 'KPH' : 'MPH';                                               // KPH : MPH
            $("#cajaxwind").html( crwspd);
            var cradir = cr[3];
            $("#cajaxwinddeg").html(cradir);
// BAROMETER
            var crbaro = (uomsys != 'I') ? (cr[6] * 1).toFixed(1) : (cr[6] * 0.0295317).toFixed(2);      // hPa, mb : inHg
            $("#cajaxbaro").html(crbaro);
            var crtre = (uomsys != 'I') ? get_barotrendmet(cr[50]) : get_barotrendimp(cr[50]);
// UMBRELLA ICON
      // Davis manual states "Rain Rate will show zero and the umbrella icon does not appear
      // until two tips of the rain bucket within a 15 minute period." Min rain rate for Umbrella icon => 0.08"/hr
            if (cr[10] > 0) { $("#cajaxumbr").html('<img src="' + imgdir + "umbr.png" + '" alt=""/>');
            } else { $("#cajaxumbr").html(''); }
// RAIN
            var crrainr = (uomsys != 'I') ? (cr[10] / 1 * 60).toFixed(1) : (cr[10] * 60 / 25.4).toFixed(2); // mm/hr : in/hr - Rain rate/hr
            var crrainh = (uomsys != 'I') ? ((cr[109] - cr[108]) / 1).toFixed(1) : ((cr[109] - cr[108]) / 25.4).toFixed(2);   // mm : in - Rain last hour
            var crraind = (uomsys != 'I') ? (cr[7] / 1).toFixed(1) : (cr[7] / 25.4).toFixed(2);          // mm : in -  so far today
            $("#cajaxrain").html(crraind);
            var crrainm = (uomsys != 'I') ? (cr[8] / 1).toFixed(1) : (cr[8] / 25.4).toFixed(2);          // mm : in -  Rain this month
            var crrainy = (uomsys != 'I') ? (cr[9] / 1).toFixed(1) : (cr[9] / 25.4).toFixed(2);          // mm : in -  Rain this year
            var crrainu = (uomsys != 'I') ? 'mm' : 'in';                                                 // mm : in -  Rain UoM
            $("#cajaxrainu").html(crrainu);
            var crrainuh = (uomsys != 'I') ? 'mm/h' : 'in/h';                                            // mm/hr : in/hr - Rain Rate UoM mm/hr
            $("#cajaxrainuh").html(crrainuh);
            var stormrn  = (uomsys != 'I') ? (vpstormrain * 1).toFixed(1) : (vpstormrain * 1).toFixed(2);// mm : in -  Storm rain UoM
            var stormrntxt = 'RAIN&nbsp;&nbsp;STORM';
// SOLAR ET UV
            if (showsolar == 'Y') {
               // Evapotranspiration not available from clientraw.txt - in clientrawextra.txt
               var cret    = (uomsys != 'I') ? (VPet * 1).toFixed(1) : (VPet / 25.4).toFixed(2);         // Evapotrans mm : in - use rain UoM
               var cruv    = (uomsys != 'I') ? (cr[79] * 1).toFixed(1) : (cr[79] * 1).toFixed(1);        // UV index
               var crsolar = (uomsys != 'I') ? (cr[127] * 1).toFixed(0) : (cr[127] * 1).toFixed(0);      // Solar Radiation W/m2
            } // End VP2 Plus
      } // End WD

// ICONS CU & WD
            $("#cajaxicon").html('<img src="' + imgdir + fcsticon + '" alt=""/>');  // forecast icon
            $("#cajaxmoon").html('<img src="' + imgdir + moonic + '" alt=""/>');    // moonphase icon
            if (console == 'VP2') { // VP2
               if (sensorlost == 1) {        // SensorContactLost 
                  var antennaon  = 'L';      // no receive symbol
                  var antennaoff = 'L';      // no receive symbol
               } else {
                  var antennaon  = 'X';      // antenna On
                  var antennaoff = ' ';      // antenna Off
               }
            } else {                // VUE
               if (sensorlost == 1) {        // SensorContactLost 
                  var antennaon  = ('<img src="' + imgdir + "antennaoff.png" + '" alt=""/>'); // antenna Off
                  var antennaoff = ('<img src="' + imgdir + "antennaoff.png" + '" alt=""/>');  // antenna Off
               } else {
                  var antennaon  = ('<img src="' + imgdir + "antennaon.png"  + '" alt=""/>');  // antenna On
                  var antennaoff = ('<img src="' + imgdir + "antennaoff.png" + '" alt=""/>');  // antenna Off
               }
            }

// OUTPUT ROTATING DATA ITEMS ##################################################
// CONSOLE  WIND SPEED - auto rotate wind speed  -> wind degrees on timeout interval (default 3 secs)
       if (windrotate == 1) {
          $("#cajaxwind").unbind('click').html(crwspd);
          $("#cajaxwindu").unbind('click').html(crwindu);
          $("#cajaxwinddu").unbind('click').html('');
       } else if (windrotate == 2) {
       if (windbutton == 0) { $("#cajaxwind").html(crwspd);}
       if (windbutton == 1) { $("#cajaxwind").html(cradir);}

          switch(windbutton)
          {
            case 0:
              $("#cajaxwind").unbind('click').html(crwspd);
              $("#cajaxwindu").unbind('click').html(crwindu);
              $("#cajaxwinddu").unbind('click').html('');
              windbutton = 1;
              break;
            case 1:
              $("#cajaxwind").unbind('click').html(cradir);
              $("#cajaxwindu").unbind('click').html('');
              $("#cajaxwinddu").unbind('click').html('&deg;');
              windbutton = 0;
              break;
            default:
              $("#cajaxwind").unbind('click').html(crwspd);
              $("#cajaxwindu").unbind('click').html(crwindu);
              $("#cajaxwinddu").unbind('click').html('');
              windbutton = 0;
              break;
          }
       }         

// CONSOLE  APPARENT TEMP - auto rotate App Temp -> Dew display on timeout interval (default 3 secs)
       if (dewrotate == 1) {
       if (appbutton == 0) { $("#cajaxapp").html(crapp);}
       if (appbutton == 1) { $("#cajaxapp").html(crdew);}

          switch(appbutton)
          {
            case 0:
              $("#cajaxapp").unbind('click').html(crapp);
              $("#app").unbind('click').html('APPARENT');
              appbutton = 1;
              break;
            case 1:
              $("#cajaxapp").unbind('click').html(crdew);
              $("#app").unbind('click').html('DEW&nbsp;');
              appbutton = 0;
              break;
            default:
              $("#cajaxapp").unbind('click').html(crapp);
              $("#app").unbind('click').html('APPARENT');
              appbutton = 0;
              break;
          }
       }
// CONSOLE  HUMIDEX - auto rotate Humidex -> Dew display on timeout interval (default 3 secs)
       if (dewrotate == 2) {
          if(appbutton == 0) { $("#cajaxapp").html(crhdex);}
          if(appbutton == 1) { $("#cajaxapp").html(crdew);}

          switch(appbutton)
          {
            case 0:
              $("#cajaxapp").unbind('click').html(crhdex);
              $("#app").unbind('click').html('HUMIDEX');
              appbutton = 1;
              break;
            case 1:
              $("#cajaxapp").unbind('click').html(crdew);
              $("#app").unbind('click').html('DEW&nbsp;');
              appbutton = 0;
              break;
            default:
              $("#cajaxapp").unbind('click').html(crhdex);
              $("#app").unbind('click').html('HUMIDEX');
              appbutton = 0;
              break;
          }
       }
// CONSOLE  HEAT INDEX - auto rotate HeatIndex -> Dew display on timeout interval (default 3 secs)
       if (dewrotate == 3) {
          if(appbutton == 0) { $("#cajaxapp").html(crheat);}
          if(appbutton == 1) { $("#cajaxapp").html(crdew);}

          switch(appbutton)
          {
            case 0:
              $("#cajaxapp").unbind('click').html(crheat);
              $("#app").unbind('click').html('HEAT');
              appbutton = 1;
              break;
            case 1:
              $("#cajaxapp").unbind('click').html(crdew);
              $("#app").unbind('click').html('DEW&nbsp;');
              appbutton = 0;
              break;
            default:
              $("#cajaxapp").unbind('click').html(crheat);
              $("#app").unbind('click').html('HEAT');
              appbutton = 0;
              break;
          }
       }
// CONSOLE  APPARENT TEMP - auto rotate Dew -> App temp -> Chill -> heat -> Dew display on timeout interval (default 3 secs)
       if (dewrotate == 4) {
          if(appbutton == 0) { $("#cajaxapp").html(crapp);}
          if(appbutton == 1) { $("#cajaxapp").html(crchill);}
          if(appbutton == 2) { $("#cajaxapp").html(crdew);}

          switch(appbutton)
          {
            case 0:
              $("#cajaxapp").unbind('click').html(crapp);
              $("#app").unbind('click').html('APPARENT');
              appbutton = 1;
              break;
            case 1:
              $("#cajaxapp").unbind('click').html(crchill);
              $("#app").unbind('click').html('CHILL');
              appbutton = 2;
              break;
            case 2:
              $("#cajaxapp").unbind('click').html(crdew);
              $("#app").unbind('click').html('DEW&nbsp;');
              appbutton = 0;
              break;
            default:
              $("#cajaxapp").unbind('click').html(crapp);
              $("#app").unbind('click').html('APPARENT');
              appbutton = 0;
              break;
          }
       }
// CONSOLE  HUMIDEX - auto rotate Dew -> Humidex -> Chill -> heat -> Dew display on timeout interval (default 3 secs)
       if (dewrotate == 5) {
          if(appbutton == 0) { $("#cajaxapp").html(crhdex);}
          if(appbutton == 1) { $("#cajaxapp").html(crchill);}
          if(appbutton == 2) { $("#cajaxapp").html(crdew);}

          switch(appbutton)
          {
            case 0:
              $("#cajaxapp").unbind('click').html(crhdex);
              $("#app").unbind('click').html('HUMIDEX');
              appbutton = 1;
              break;
            case 1:
              $("#cajaxapp").unbind('click').html(crchill);
              $("#app").unbind('click').html('CHILL');
              appbutton = 2;
              break;
            case 2:
              $("#cajaxapp").unbind('click').html(crdew);
              $("#app").unbind('click').html('DEW&nbsp;');
              appbutton = 0;
              break;
            default:
              $("#cajaxapp").unbind('click').html(crhdex);
              $("#app").unbind('click').html('HUMIDEX');
              appbutton = 0;
              break;
          }
       }
// CONSOLE  HEAT INDEX - auto rotate Heatindex -> Chill -> Dew display on timeout interval (default 3 secs)
       if (dewrotate == 6) {
          if(appbutton == 0) { $("#cajaxapp").html(crheat);}
          if(appbutton == 1) { $("#cajaxapp").html(crchill);}
          if(appbutton == 2) { $("#cajaxapp").html(crdew);}

          switch(appbutton)
          {
            case 0:
              $("#cajaxapp").unbind('click').html(crheat);
              $("#app").unbind('click').html('HEAT');
              appbutton = 1;
              break;
            case 1:
              $("#cajaxapp").unbind('click').html(crchill);
              $("#app").unbind('click').html('CHILL');
              appbutton = 2;
              break;
            case 2:
              $("#cajaxapp").unbind('click').html(crdew);
              $("#app").unbind('click').html('DEW&nbsp;');
              appbutton = 0;
              break;
            default:
              $("#cajaxapp").unbind('click').html(crheat);
              $("#app").unbind('click').html('HEAT');
              appbutton = 0;
              break;
          }
       }
// CONSOLE  APPARENT TEMP - auto rotate Dew -> App temp -> Chill -> heat display on timeout interval (default 3 secs)
       if (dewrotate == 7) {
          if(appbutton == 0) { $("#cajaxapp").html(crapp);}
          if(appbutton == 1) { $("#cajaxapp").html(crchill);}
          if(appbutton == 2) { $("#cajaxapp").html(crheat);}
          if(appbutton == 3) { $("#cajaxapp").html(crdew);}

          switch(appbutton)
          {
            case 0:
              $("#cajaxapp").unbind('click').html(crapp);
              $("#app").unbind('click').html('APPARENT');
              appbutton = 1;
              break;
            case 1:
              $("#cajaxapp").unbind('click').html(crchill);
              $("#app").unbind('click').html('CHILL');
              appbutton = 2;
              break;
            case 2:
              $("#cajaxapp").unbind('click').html(crheat);
              $("#app").unbind('click').html('HEAT');
              appbutton = 3;
              break;
            case 3:
              $("#cajaxapp").unbind('click').html(crdew);
              $("#app").unbind('click').html('DEW&nbsp;');
              appbutton = 0;
              break;
            default:
              $("#cajaxapp").unbind('click').html(crapp);
              $("#app").unbind('click').html('APPARENT');
              appbutton = 0;
              break;
          }
       }
// CONSOLE  APPARENT TEMP - auto rotate Dew -> Humidex -> Chill -> heat -> dew display on timeout interval (default 3 secs)
       if (dewrotate == 8) {
          if(appbutton == 0) { $("#cajaxapp").html(crhdex);}
          if(appbutton == 1) { $("#cajaxapp").html(crchill);}
          if(appbutton == 2) { $("#cajaxapp").html(crheat);}
          if(appbutton == 3) { $("#cajaxapp").html(crdew);}

          switch(appbutton)
          {
            case 0:
              $("#cajaxapp").unbind('click').html(crhdex);
              $("#app").unbind('click').html('HUMIDEX');
              appbutton = 1;
              break;
            case 1:
              $("#cajaxapp").unbind('click').html(crchill);
              $("#app").unbind('click').html('CHILL');
              appbutton = 2;
              break;
            case 2:
              $("#cajaxapp").unbind('click').html(crheat);
              $("#app").unbind('click').html('HEAT');
              appbutton = 3;
              break;
            case 3:
              $("#cajaxapp").unbind('click').html(crdew);
              $("#app").unbind('click').html('DEW&nbsp;');
              appbutton = 0;
              break;
            default:
              $("#cajaxapp").unbind('click').html(crhdex);
              $("#app").unbind('click').html('HUMIDEX');
              appbutton = 0;
              break;
          }
       } // END Temp rotates

// CONSOLE  DAILY RAIN - auto rotate Daily Rain -> ET -> Daily Rain display on timeout interval (default 3 secs)
      if (dayrnrotate == 1 ) {
        if (showsolar == 'Y') {
          if (dayrainbutton == 0) { $("#cajaxrain").html(crraind);}
          if (dayrainbutton == 1) { $("#cajaxrain").html(cret);}
          switch(dayrainbutton)
          {
            case 0:
              $("#cajaxrain").unbind('click').html(crraind);
              $("#rrd").unbind('click').html('DAILY&nbsp;&nbsp;RAIN');
              dayrainbutton = 1;
              break;
            case 1:
              $("#cajaxrain").unbind('click').html(cret);
              $("#rrd").unbind('click').html('ET');
              dayrainbutton = 0;
              break;
            default:
              $("#cajaxrain").unbind('click').html(crraind);
              $("#rrd").unbind('click').html('DAILY&nbsp;&nbsp;RAIN');
              dayrainbutton = 0;
              break;
          } // End case
        } // End Show Solar test
      } // End dayrnrotate == 1

// CONSOLE  DAILY RAIN - auto rotate Daily Rain ->Storm Rain -> Daily Rain display on timeout interval (default 3 secs)
      if (dayrnrotate == 2 ) {
        if (stormrn > 0 && showsolar == 'Y') { // dailyrain + stormrn + solar(ET)
          if (dayrainbutton == 0) { $("#cajaxrain").html(crraind);}
          if (dayrainbutton == 1) { $("#cajaxrain").html(cret);}
          if (dayrainbutton == 2) { $("#cajaxrain").html(stormrn);}
          switch(dayrainbutton)
          {
            case 0:
              $("#cajaxrain").unbind('click').html(crraind);
              $("#rrd").unbind('click').html('DAILY&nbsp;&nbsp;RAIN');
              dayrainbutton = 1;
              break;
            case 1:
              $("#cajaxrain").unbind('click').html(cret);
              $("#rrd").unbind('click').html('ET');
              dayrainbutton = 2;
              break;
            case 2:
              $("#cajaxrain").unbind('click').html(stormrn);
              $("#rrd").unbind('click').html(stormrntxt);
              dayrainbutton = 0;
              break;
            default:
              $("#cajaxrain").unbind('click').html(crraind);
              $("#rrd").unbind('click').html('DAILY&nbsp;&nbsp;RAIN');
              dayrainbutton = 0;
              break;
          } // End case
        } else if (stormrn > 0) {   // End daily rain + solar(ET) + stormrn

      // daily rain + storm Rain
          if (dayrainbutton == 0) { $("#cajaxrain").html(crraind);}
          if (dayrainbutton == 1) { $("#cajaxrain").html(stormrn);}

          switch(dayrainbutton)
          {
            case 0:
              $("#cajaxrain").unbind('click').html(crraind);
              $("#rrd").unbind('click').html('DAILY&nbsp;&nbsp;RAIN');
              dayrainbutton = 1;
              break;
            case 1:
              $("#cajaxrain").unbind('click').html(stormrn);
              $("#rrd").unbind('click').html(stormrntxt);
              dayrainbutton = 0;
              break;
            default:
              $("#cajaxrain").unbind('click').html(crraind);
              $("#rrd").unbind('click').html('DAILY&nbsp;&nbsp;RAIN');
              dayrainbutton = 0;
              break;
          } // End case
        } else if (showsolar == 'Y') { // End daily rain + stormrn

      // daily rain + solar
          if (dayrainbutton == 0) { $("#cajaxrain").html(crraind);}
          if (dayrainbutton == 1) { $("#cajaxrain").html(cret);}

          switch(dayrainbutton)
          {
            case 0:
              $("#cajaxrain").unbind('click').html(crraind);
              $("#rrd").unbind('click').html('DAILY&nbsp;&nbsp;RAIN');
              dayrainbutton = 1;
              break;
            case 1:
              $("#cajaxrain").unbind('click').html(cret);
              $("#rrd").unbind('click').html('ET');
              dayrainbutton = 0;
              break;
            default:
              $("#cajaxrain").unbind('click').html(crraind);
              $("#rrd").unbind('click').html('DAILY&nbsp;&nbsp;RAIN');
              dayrainbutton = 0;
              break;
          } // End case
        } // End daily rain + Solar(ET)
      }  // End dayrnrotate == 2

// CONSOLE  RAIN - auto rotate Rain Rate -> Rain Hour -> Rain Month -> Rain Year display on timeout interval (default 3 secs)
          if(rainbutton == 0) { $("#cajaxrainratehr").html(crrainr);}
          if(rainbutton == 1) { $("#cajaxrainratehr").html(crrainh);}
          if(rainbutton == 2) { $("#cajaxrainratehr").html(crrainm);}
          if(rainbutton == 3) { $("#cajaxrainratehr").html(crrainy);}

          switch(rainbutton)
          {
            case 0:
              $("#cajaxrainratehr").unbind('click').html(crrainr);
              $("#rrh").unbind('click').html('RAIN&nbsp;&nbsp;RATE');
              $("#rrth").unbind('click').html(crrainuh);

              rainbutton = 1;
              break;
            case 1:
              $("#cajaxrainratehr").unbind('click').html(crrainh);
              $("#rrh").unbind('click').html('RAIN&nbsp;&nbsp;HOUR');
              $("#rrth").unbind('click').html(crrainu);
              rainbutton = 2;
              break;
            case 2:
              $("#cajaxrainratehr").unbind('click').html(crrainm);
              $("#rrh").unbind('click').html('RAIN&nbsp;&nbsp;MONTH');
              $("#rrth").unbind('click').html(crrainu);
              rainbutton = 3;
              break;
            case 3:
              $("#cajaxrainratehr").unbind('click').html(crrainy);
              $("#rrh").unbind('click').html('RAIN&nbsp;&nbsp;YEAR');
              $("#rrth").unbind('click').html(crrainu);
              rainbutton = 0;
              break;
            default:
              $("#cajaxrainratehr").unbind('click').html(crrainr);
              $("#rrh").unbind('click').html('RAIN&nbsp;&nbsp;RATE');
              $("#rrth").unbind('click').html(crrainuh);
              rainbutton = 0;
              break;
          }

// CONSOLE  TEMP IN|UV  HUM IN|SOLAR - auto rotate display on timeout interval (default 3 secs)
        if (showsolar == 'Y') {
          if(tempinbutton == 0) { $("#cajaxitemp").html(critemp);}
          if(tempinbutton == 1) { $("#cajaxitemp").html(crsolar);}

          switch(tempinbutton)
          {
            case 0:
              $("#cajaxitemp").unbind('click').html(critemp);
              $("#itemp").unbind('click').html('TEMP IN');
              $("#itempuom").unbind('click').html(crtempu);
              $("#cajaxihumidity").unbind('click').html(crihum);
              $("#ihum").unbind('click').html('HUM IN');
              $("#ihumuom").unbind('click').html('%');
              $("#index").unbind('click').html('');
              tempinbutton = 1;
              break;
            case 1:
              $("#cajaxitemp").unbind('click').html(crsolar);
              $("#itemp").unbind('click').html('SOL W/m2');
              $("#itempuom").unbind('click').html('');
              $("#cajaxihumidity").unbind('click').html(cruv);
              $("#ihum").unbind('click').html('UV');
              $("#ihumuom").unbind('click').html('');
              $("#index").unbind('click').html('index');
              tempinbutton = 0;
              break;
            default:
              $("#cajaxitemp").unbind('click').html(critemp);
              $("#itemp").unbind('click').html('TEMP IN');
              $("#itempuom").unbind('click').html(crtempu);
              $("#cajaxihumidity").unbind('click').html(crihum);
              $("#ihum").unbind('click').html('HUM IN');
              $("#ihumuom").unbind('click').html('%');
              $("#index").unbind('click').html('');
              tempinbutton = 0;
              break;
          } // end switch
        } else {
              $("#cajaxitemp").unbind('click').html(critemp);
              $("#itemp").unbind('click').html('TEMP IN');
              $("#itempuom").unbind('click').html(crtempu);
              $("#cajaxihumidity").unbind('click').html(crihum);
              $("#ihum").unbind('click').html('HUM IN');
              $("#ihumuom").unbind('click').html('%');
              $("#index").unbind('click').html('');
        }// End showsolar

// ANTENNA ICON - SWITCH ON/OFF at timeout interval (default 3 secs)
          switch(antennaicon)
          {
            case 0:
              $("#cajaxanten").unbind('click').html(antennaon);
              antennaicon = 1;
              break;
            case 1:
              $("#cajaxanten").unbind('click').html(antennaoff);
              antennaicon = 0;
              break;
            default:
              $("#cajaxanten").unbind('click').html(antennaon);
              antennaicon = 0;
              break;
          } // end switch
        
// Arrows
   // Wind
           var avgwind = $("#wdir");
           options.dotsoffset = avgwinddotsoffset;
           options.dircrvalue = cradir;
           options.windgauge = true;
           $.ga(avgwind, data, options); 
           options.windgauge = false;
   // Baro trend
           var barotrend = $("#cajaxbaroarrow");
           options.trecrvalue = crtre;
           options.barotrend = true;
           $.ga(barotrend, data, options); 
           options.barotrend = false;

          cr = '';
          cr = false;

      } // End onDataReceived(series) function

      $.ajax({
         url: dataurl,
         method: 'GET',
         dataType: 'text/plain',
         timeout: 15000,           // 15 sec typical get 75~175ms
         cache: false,
         tryCount : 0,
         retryLimit : 2,
         success: onDataReceived,
         error : function(xhr, textStatus, errorThrown ) {
            if (textStatus === 'timeout') {
               this.tryCount++;
               if (this.tryCount <= this.retryLimit) {
                  //try again
                  $.ajax(this);
                  return;
               }
               return;
            }
         }
      });

      setTimeout(update, itimeout*1000);

// Baro trend arrow angle metric
      function get_barotrendmet(btrnd) {
         if (btrnd >  0.8) { return('16'); }
         if (btrnd >  0.5) { return('30'); }
         if (btrnd >  0.3) { return('45'); }
         if (btrnd >  0.15) { return('60'); }
         if (btrnd >  0.05) { return('75'); }
         if ((btrnd >= -0.05) && (btrnd <= 0.05)) { return('90'); }
         if (btrnd < -0.8) { return('164'); }
         if (btrnd < -0.5) { return('150'); }
         if (btrnd < -0.3) { return('135'); }
         if (btrnd < -0.15) { return('120'); }
         if (btrnd < -0.05) { return('105'); }
         return(btrnd);
      }
// Baro trend arrow angle imperial
      function get_barotrendimp(btrnd) {
         if (btrnd >  0.04) { return('16'); }
         if (btrnd >  0.025) { return('30'); }
         if (btrnd >  0.015) { return('45'); }
         if (btrnd >  0.0075) { return('60'); }
         if (btrnd >  0.0025) { return('75'); }
         if ((btrnd >= -0.0025) && (btrnd <= 0.0025)) { return('90'); }
         if (btrnd < -0.04) { return('164'); }
         if (btrnd < -0.025) { return('150'); }
         if (btrnd < -0.015) { return('135'); }
         if (btrnd < -0.0075) { return('120'); }
         if (btrnd < -0.0025) { return('105'); }
         return(btrnd);
      }

   }; // End Function update
}); // End Function
