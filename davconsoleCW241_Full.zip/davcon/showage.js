// <![CDATA[
// FOR use with "Live" Davis Console scripts
// This script is an adaptation of the Saratoga ajaxCUwx.js & ajaxWDwx.js ajax scripts
// It has been reduced to the minimum code required to provide the necessary interface and output
//    to provide 'live' counter data to show the age of realtime.txt or clientraw.txt
//
// Key original credits from the source file;
// Special thanks to: Kevin Reed http://www.tnetweather.com/
// Special thanks to: Pinto http://www.joske-online.be/
// Cheerfully borrowed from Tom at CarterLake.org and adapted by
//    Ken True - Saratoga-weather.org  21-May-2006
// Mike Challis http://www.642weather.com/weather/index.php
// FourOhFour on wxforum.net http://skigod.us/
// --- Version 3.04 - 19-Aug-2013
// original ajaxCUwx.js file available at http://saratoga-weather.org/wxtemplates/
//
// Adaptation to showage.js by BCJKiwi http://silveracorn.co.nz/weather
// Oct 2013 Ver CU1.0      First release for the CU standard template website version of the 'live' Davis Console scripts.
// May 2014 Ver CU2.0      Revised to also enable use with V2.4.1 CU and WD running Saratoga Template Websites 

// ####################################################################################
// ##  D O   N O T   C H A N G E   A N Y T H I N G   I N   T H I S   S C R I P T!!!  ##
// ####################################################################################
var reloadTimedc   = realint;      // realtint = "real time" file upload interval in millisecs
var realtimeFiledc = dataurl;      // URL location of realtime.txt relative to document root of website
var counterSecdcup = 0;            // for MCHALLIS counter script from weather-watch.com (adapted by K. True)
var counterSecdcdn = 0;            // for MCHALLIS counter script from weather-watch.com (adapted by K. True)
var updatesdc      = 0;            // update counter for limit by maxupdates
var lastajaxtimeformatdc = 'unknown'; //used to reset the counter when a real update is done

// Mike Challis' counter function (adapted by Ken True / BCJKiwi)
function ajax_countupdc() {  // count up
   var elementdc = document.getElementById("ajaxcounterdcup");
   if (elementdc) {
      elementdc.innerHTML = counterSecdcup + 1;
      counterSecdcup++;
   }
}

function ajax_countdndc() { // count down
   var elementdc = document.getElementById("ajaxcounterdcdn");
   if (elementdc) {
      elementdc.innerHTML = reloadTimedc/1000 - counterSecdcdn;
      if (elementdc.innerHTML < 0) {elementdc.innerHTML = "?";} else {
         counterSecdcdn++;
      }
   }
}

function ajaxRequestdc () {
   /* find the handler for AJAX based on availability of the request object */
   try { var requestdc = new XMLHttpRequest() /* non IE browser (or IE8 native) */ }
      catch(e1) // no Ajax support
      { requestdc = false; alert('Sorry.. AJAX updates are not available for your browser.'); }
   return requestdc;
}
// ------------------------------------------------------------------------------------------
//  main function.. read realtime.txt/clientraw.txt and format <span id="ajax..."></span> areas
// ------------------------------------------------------------------------------------------
function ajaxLoaderdc(url) {
   var xx = new ajaxRequestdc();
   if (xx) { // got something back
      xx.onreadystatechange = function() {
         try {
            if (xx.readyState == 4 && xx.status == 200) {  // Mike Challis added fix to fix random error: NS_ERROR_NOT_AVAILABLE 
               if (wxsoftware == 'CU') {
                  var realtimedc = xx.responseText.split(' ');
               // now make sure we got the essential part of realtime.txt  -- thanks to Johnnywx
                  var cupatterndc=/\d+(\/|-|\.)\d+(\/|-|\.)\d+ \d+:\d+:\d+/; // looks for 'dd/dd/dd' date string followed by 'hh:mm:ss'
               // If we have a valid realtime file
                  if(cupatterndc.test(xx.responseText)) {
                     var ajaxtimeformatdc = realtimedc[1];  // current time of observation in realtime.txt
                  } // END if(realtimedc[0]
               } else if (wxsoftware == 'WD'){
                  var clientrawdc = xx.responseText.split(' ');
               // now make sure we got the entire clientraw.txt  -- thanks to Johnnywx
               // valid clientraw.txt has '12345' at start and '!!' at end of record
                  var wdpatterndc=/\d+\.\d+.*!!/; // looks for '!!nn.nn!!' version string 
               // If we have a valid clientraw file
                  if(clientrawdc[0] == '12345' && wdpatterndc.test(xx.responseText)) {
                     var ajaxtimeformatdc = (clientrawdc[29]+':'+clientrawdc[30]+':'+clientrawdc[31]); // current time of observation in clientraw.txt
                  } // END if(clientrawdc[0]
               }
               if (lastajaxtimeformatdc != ajaxtimeformatdc) {
                  counterSecdcup = 0;                       // reset timer
                  counterSecdcdn = 0;                       // reset timer
                  lastajaxtimeformatdc = ajaxtimeformatdc;  // remember this time
               }
            } // END if (xx.readyState == 4 && xx.status == 200)
         } // END try
         catch(e){}  // Mike Challis added fix to fix random error: NS_ERROR_NOT_AVAILABLE
      } // END xx.onreadystatechange = function() {
      xx.open("GET", url, true);
      xx.send(null);
      setTimeout("ajaxLoaderdc(realtimeFiledc + '?' + new Date().getTime())", reloadTimedc); // get new data 
   } // end got something back
} // end ajaxLoaderdc function

window.setInterval("ajax_countupdc()", 1000); // run the counter for mseconds since update
window.setInterval("ajax_countdndc()", 1000); // run the counter for mseconds since update
// invoke when first loaded on page
ajaxLoaderdc(realtimeFiledc + '?' + new Date().getTime(), reloadTimedc);

// ]]>
